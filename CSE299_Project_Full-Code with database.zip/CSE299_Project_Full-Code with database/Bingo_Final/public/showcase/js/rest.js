fetch("/data1")
  .then((response) => response.json())
  .then((data) => {
    window.addEventListener("beforeunload", function () {
      // Scroll the page to the top
      window.scrollTo(0, 0);
    });

    document.getElementById("loading").innerHTML = "";
    // Update HTML elements with project data
    const projectsContainer = document.getElementById("container");

    data.forEach((project) => {
      const featuresArray = createArray(project.features);

      const projectDiv = document.createElement("div");
      projectDiv.classList.add("main-body-individual-project-seperation-div");
      projectDiv.innerHTML = `
      <div class="main-body-image-overlay-div">
        <img src= ${project.thumbnail} />
        <div class="main-body-image-overlay-text">
          <p>This is a sample image</p>
        </div>
      </div>

      <div class="main-body-text">
        <h1>${project.title}</h1>
        <div class="project1">
            <h2>Category: ${project.category}</h2> <br>
            <div class="features">
              <div class="feature">${featuresArray[0]}</div>
              <div class="feature">${featuresArray[1]}</div>
              <div class="feature">${featuresArray[2]}</div>
            </div>
            <div class="short-description">
              <p>
                <b>Short Description</b> <br>
                ${project.short_description}
              </p>
            </div>
        </div>
      </div>
      <div class="social">
        <div class="project_like rearrange" onclick="handleLikeClick(${project.project_ID}, true)">
          <i class="fa-solid fa-thumbs-up"></i>
          <p>Like</p>
          <span id="likeCount_projectId">0</span>
        </div>
        <div class="project_comment rearrange">
          <button id="open-comments">Open Comments</button>
          <div id="comment-window" class="comment-container">  
              <h2 id="comment_window_heading">Comments</h2>
              <button class="closing_button" id="window_closing_button">X</button>
              <ul id="comment-list"> </ul>
      
              <form id="comment-form">
                  <textarea name="comment" id="comment-text" placeholder="Add a comment..."></textarea>
                  <button type="submit">Post</button>
              </form>
          </div>
        </div>
        <div class="project_share rearrange">
          <i class="fa-solid fa-share-nodes"></i>
            <p>Share</p>
        </div>
      </div>
      `;
      projectsContainer.appendChild(projectDiv);
      console.log(projectDiv);
    });
    const tmp = document.createElement("div");
    tmp.classList.add("no-more-projects");
    tmp.innerHTML = `<p>No more projects available</p>`;
    projectsContainer.appendChild(tmp);
  })
  .catch((error) => console.error("Error fetching data:", error));

function createArray(commaSeparatedText) {
  // Create an array from comma-separated text
  const featuresArray = commaSeparatedText.split(",");

  // Trim whitespace from each item in the array
  const trimmedFeaturesArray = featuresArray.map((feature) => feature.trim());
  return trimmedFeaturesArray;
}

function searchProjects() {
  const searchInput = document
    .getElementById("searchInput")
    .value.toLowerCase();
  const projects = document.querySelectorAll(
    ".main-body-individual-project-seperation-div"
  );

  projects.forEach((project) => {
    const title = project.querySelector("h1").innerText.toLowerCase();
    const category = project
      .querySelector(".project1 h2")
      .innerText.toLowerCase();
    const features = project.querySelectorAll(".features .feature");
    const featuresText = Array.from(features)
      .map((feature) => feature.innerText.toLowerCase())
      .join(",");

    // Check if search query matches title, category, or features
    if (
      title.includes(searchInput) ||
      category.includes(searchInput) ||
      featuresText.includes(searchInput)
    ) {
      project.style.display = "flex"; // Show matching projects
    } else {
      project.style.display = "none"; // Hide non-matching projects
    }
  });
}

//drop down for filtering
function toggleDropdown() {
  var dropdown = document.getElementById("filterOptions");
  if (dropdown.style.display === "block") {
    dropdown.style.display = "none";
  } else {
    dropdown.style.display = "block";
  }
}

// Function to fetch latest projects
function fetchLatestProjects() {
  fetch("/latest-projects")
    .then((response) => response.json())
    .then((data) => {
      // Clear previous projects
      const projectsContainer = document.getElementById("container");
      projectsContainer.innerHTML = "";

      data.forEach((project) => {
        const featuresArray = createArray(project.features);

        const projectDiv = document.createElement("div");
        projectDiv.classList.add("main-body-individual-project-seperation-div");
        projectDiv.innerHTML = `
          <!-- Project HTML here -->
          <div class="main-body-image-overlay-div">
      <img src= ${project.thumbnail} />
      <div class="main-body-image-overlay-text">
        <p>This is a sample image</p>
      </div>
    </div>

    <div class="main-body-text">
      <h1>${project.title}</h1>
      <div class="project1">
          <h2>Category: ${project.category}</h2> <br>
          <div class="features">
            <div class="feature">${featuresArray[0]}</div>
            <div class="feature">${featuresArray[1]}</div>
            <div class="feature">${featuresArray[2]}</div>
          </div>
          <div class="short-description">
            <p>
              <b>Short Description</b> <br>
              ${project.short_description}
            </p>
          </div>
          
      </p>
    </div>
    <div class="social">
      <div class="project_like rearrange" onclick="handleLikeClick(${project.project_ID}, true)">
        <i class="fa-solid fa-thumbs-up"></i>
        <p>Like</p>
        <span id="likeCount_projectId">0</span>
      </div>
      <div class="project_comment rearrange">
        <i class="fa-solid fa-comment"></i>
        <p>Comment</p>
      </div>
      <div class="project_share rearrange">
        <i class="fa-solid fa-share-nodes"></i>
          <p>Share</p>
      </div>
    </div>
        `;
        projectsContainer.appendChild(projectDiv);
      });
    })
    .catch((error) => console.error("Error fetching latest projects:", error));
}

// Event listener for filter button
document.getElementById("latestFilter").addEventListener("click", function () {
  fetchLatestProjects();
});

//comment
//Read different elements of the HTML into variables
// Event delegation for handling clicks on the "Open Comments" button

document.addEventListener("click", function (event) {
  if (event.target && event.target.id === "open-comments") {
    const commentButton = document.getElementById("open-comments");
    const commentWindow = document.getElementById("comment-window");
    const commentForm = document.getElementById("comment-form");
    const commentList = document.getElementById("comment-list");
    const closingButton = document.getElementById("window_closing_button");

    //Hide the comment window when the closing button is clicked
    closingButton.addEventListener("click", () => {
      commentWindow.style.display = "none";
    });

    //When the comment button is clicked show the comment section
    commentButton.addEventListener("click", () => {
      commentWindow.style.display = "block";
    });

    // Add functionality to submit comments (for illustration, doesn't save comments)
    commentForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const commentText = document.getElementById("comment-text").value;

      // Logic for adding comment to the Database
      //Only allow to add the comment if the comment is not empty
      if (commentText.length !== 0) {
        //Creating a list component
        const newComment = document.createElement("li");

        //Username handling
        const usernameSpan = document.createElement("span");
        username = "You";
        usernameSpan.className = "username";
        usernameSpan.textContent = username + ": ";

        //Comment text insertion into the text section of the list element
        const commentSpan = document.createElement("span");
        commentSpan.textContent = commentText;

        //Delete button handling
        const deleteButton = document.createElement("button");
        deleteButton.className = "delete-button";

        //Delete button icon handling
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-trash";
        deleteButton.appendChild(icon);

        //Delete button clicked will remove the list element from the list
        deleteButton.addEventListener("click", function () {
          commentList.removeChild(newComment);
        });

        const dateAndTime = document.createElement("span");
        dateAndTime.className = "date_time";
        dateAndTime.textContent = "1m ago";

        //Adding all the different child elements of the new comment to the new comment
        newComment.appendChild(usernameSpan);
        newComment.appendChild(commentSpan);
        newComment.appendChild(deleteButton);
        newComment.appendChild(dateAndTime);
        commentList.appendChild(newComment);

        //New comment styles
        newComment.style.cssText =
          "background-color: #fff; border-radius: 10px; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); padding: 15px; ";
      }

      //Clear comment input
      document.getElementById("comment-text").value = "";
    });
  }
});
