//Read different elements of the HTML into variables
const commentButton = document.getElementById('open-comments');
const commentWindow = document.getElementById('comment-window');
const commentForm = document.getElementById('comment-form');
const commentList = document.getElementById('comment-list');
const closingButton = document.getElementById('window_closing_button')

//Hide the comment window when the closing button is clicked
closingButton.addEventListener('click', () => {
    commentWindow.style.display = 'none';
});


//When the comment button is clicked show the comment section
commentButton.addEventListener('click', () => {
  commentWindow.style.display = 'block';
});

// Add functionality to submit comments (for illustration, doesn't save comments)
commentForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const commentText = document.getElementById('comment-text').value;
  
  // Logic for adding comment to the Database
  //Only allow to add the comment if the comment is not empty
  if(commentText.length !== 0){
    //Creating a list component
    const newComment = document.createElement('li');

    //Username handling
    const usernameSpan = document.createElement('span');
    username = "You";
    usernameSpan.className = "username";
    usernameSpan.textContent = username + ": ";
    
    //Comment text insertion into the text section of the list element
    const commentSpan = document.createElement('span');
    commentSpan.textContent = commentText;


    //Delete button handling
    const deleteButton = document.createElement('button');
    deleteButton.className = "delete-button";
    
    //Delete button icon handling
    const icon = document.createElement("i");
    icon.className = "fa-solid fa-trash"
    deleteButton.appendChild(icon);


    //Delete button clicked will remove the list element from the list
    deleteButton.addEventListener('click', function() {
      commentList.removeChild(newComment);
    });

    const dateAndTime = document.createElement('span');
    dateAndTime.className = "date_time";
    dateAndTime.textContent = "1m ago";
    
    //Adding all the different child elements of the new comment to the new comment
    newComment.appendChild(usernameSpan);
    newComment.appendChild(commentSpan);
    newComment.appendChild(deleteButton);
    newComment.appendChild(dateAndTime)
    commentList.appendChild(newComment);
    
    //New comment styles
    newComment.style.cssText = 'background-color: #fff; border-radius: 10px; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); padding: 15px; ';

  }
  
  //Clear comment input
  document.getElementById('comment-text').value = '';
});

