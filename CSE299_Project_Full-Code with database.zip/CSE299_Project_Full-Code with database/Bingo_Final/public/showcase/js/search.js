function searchProjects() {
    const searchInput = document
      .getElementById("searchInput")
      .value.toLowerCase();
    const projects = document.querySelectorAll(
      ".main-body-individual-project-seperation-div"
    );
  
    projects.forEach((project) => {
      const title = project.querySelector("h1").innerText.toLowerCase();
      const category = project
        .querySelector(".project1 h2")
        .innerText.toLowerCase();
      const features = project.querySelectorAll(".features .feature");
      const featuresText = Array.from(features)
        .map((feature) => feature.innerText.toLowerCase())
        .join(",");
  
      // Check if search query matches title, category, or features
      if (
        title.includes(searchInput) ||
        category.includes(searchInput) ||
        featuresText.includes(searchInput)
      ) {
        project.style.display = "flex"; // Show matching projects
      } else {
        project.style.display = "none"; // Hide non-matching projects
      }
    });
  }