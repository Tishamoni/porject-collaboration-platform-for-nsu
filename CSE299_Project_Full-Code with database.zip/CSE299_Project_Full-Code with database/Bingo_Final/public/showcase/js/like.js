// const likeButton = document.getElementById("like-button");
// const likeCountSpan = document.getElementById("like-count");

const likeButton1 = document.getElementById(`like-button-1`);
const likeButton2 = document.getElementById(`like-button-2`);
const likeButton3 = document.getElementById(`like-button-3`);
const likeButton4 = document.getElementById(`like-button-4`);
const likeButton5 = document.getElementById(`like-button-5`);


const likeCountSpan1 = document.getElementById("like-count-1");
const likeCountSpan2 = document.getElementById("like-count-2");
const likeCountSpan3 = document.getElementById("like-count-3");
const likeCountSpan4 = document.getElementById("like-count-4");
const likeCountSpan5 = document.getElementById("like-count-5");


let likeCount = null; // Initialize likeCount to null

// Send request to server to update like count in database
const projectId = 1;
console.log(projectId);
fetch(`/like`)
  .then(response => response.json())
  .then(data => {
    // Handle response from server if needed
    console.log(data);
    likeCount = data.likeCount;
    // Update like count in the UI after receiving the updated count from the server
    // updateLikeCount();
  })
  .catch(error => {
    console.error("Error updating like count:", error);
  });

// Update like count in the UI
function updateLikeCount1() {
  // Check if likeCount is a valid number
  
  if (!isNaN(likeCount)) {
    likeCountSpan1.textContent = likeCount;
  } else {
    // likeCountSpan.textContent = "0"; // Set default value if likeCount is not a number
  }
}

function updateLikeCount2() {
  // Check if likeCount is a valid number
  if (!isNaN(likeCount)) {
    likeCountSpan2.textContent = likeCount;
  } else {
    // likeCountSpan.textContent = "0"; // Set default value if likeCount is not a number
  }
}

function updateLikeCount3() {
  // Check if likeCount is a valid number
  if (!isNaN(likeCount)) {
    likeCountSpan3.textContent = likeCount;
  } else {
    // likeCountSpan.textContent = "0"; // Set default value if likeCount is not a number
  }
}

function updateLikeCount4() {
  // Check if likeCount is a valid number
  if (!isNaN(likeCount)) {
    likeCountSpan4.textContent = likeCount;
  } else {
    // likeCountSpan.textContent = "0"; // Set default value if likeCount is not a number
  }
}


function updateLikeCount5() {
  // Check if likeCount is a valid number
  // likeCount = parseInt(likeCountSpan1.textContent)
  if (!isNaN(likeCount)) {
    likeCountSpan5.textContent = likeCount;
  } else {
    // likeCountSpan.textContent = "0"; // Set default value if likeCount is not a number
  }
}



likeButton1.addEventListener("click", function() {
  // Check if likeCount is a valid number before updating it
  likeCount = parseInt(likeCountSpan1.textContent)
  if (!isNaN(likeCount)) {
    likeCount = this.classList.toggle("liked") ? likeCount + 1 : likeCount - 1;
    updateLikeCount1();
  }
  
  //The result of this.classList.toggle("liked") will be true if the class was added, and false if it was removed.
    
  // Toggle between outline and solid heart
  const heartIcon = this.querySelector("i");
  heartIcon.classList.toggle("far"); 
  heartIcon.classList.toggle("fas");
  
});

likeButton2.addEventListener("click", function() {
  likeCount = parseInt(likeCountSpan2.textContent)
  // Check if likeCount is a valid number before updating it
  if (!isNaN(likeCount)) {
    likeCount = this.classList.toggle("liked") ? likeCount + 1 : likeCount - 1;
    updateLikeCount2();
  }
  
  //The result of this.classList.toggle("liked") will be true if the class was added, and false if it was removed.
    
  // Toggle between outline and solid heart
  const heartIcon = this.querySelector("i");
  heartIcon.classList.toggle("far"); 
  heartIcon.classList.toggle("fas");
  
});

likeButton3.addEventListener("click", function() {
  likeCount = parseInt(likeCountSpan3.textContent)
  // Check if likeCount is a valid number before updating it
  if (!isNaN(likeCount)) {
    likeCount = this.classList.toggle("liked") ? likeCount + 1 : likeCount - 1;
    updateLikeCount3();
  }
  
  //The result of this.classList.toggle("liked") will be true if the class was added, and false if it was removed.
    
  // Toggle between outline and solid heart
  const heartIcon = this.querySelector("i");
  heartIcon.classList.toggle("far"); 
  heartIcon.classList.toggle("fas");
  
});

likeButton4.addEventListener("click", function() {
  likeCount = parseInt(likeCountSpan4.textContent)
  // Check if likeCount is a valid number before updating it
  if (!isNaN(likeCount)) {
    likeCount = this.classList.toggle("liked") ? likeCount + 1 : likeCount - 1;
    updateLikeCount4();
  }
  
  //The result of this.classList.toggle("liked") will be true if the class was added, and false if it was removed.
    
  // Toggle between outline and solid heart
  const heartIcon = this.querySelector("i");
  heartIcon.classList.toggle("far"); 
  heartIcon.classList.toggle("fas");
  
});

likeButton5.addEventListener("click", function() {
  likeCount = parseInt(likeCountSpan5.textContent)
  // Check if likeCount is a valid number before updating it
  if (!isNaN(likeCount)) {
    likeCount = this.classList.toggle("liked") ? likeCount + 1 : likeCount - 1;
    updateLikeCount5();
  }
  
  //The result of this.classList.toggle("liked") will be true if the class was added, and false if it was removed.
    
  // Toggle between outline and solid heart
  const heartIcon = this.querySelector("i");
  heartIcon.classList.toggle("far"); 
  heartIcon.classList.toggle("fas");
  
});

