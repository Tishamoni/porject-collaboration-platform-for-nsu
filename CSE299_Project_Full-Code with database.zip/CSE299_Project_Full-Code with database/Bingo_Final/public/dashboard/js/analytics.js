fetch("/top-projects")
      .then(response => response.json())
      .then(data => {
        
        console.log(data.likeCount);
      })
      .catch(error => {
        console.error("Error updating like count:", error);
      });

  // BAR CHART
const barChartOptions = {
series: [
{
  data: [4, 1, 0, 0, 0],
  name: 'Like',
},
],
chart: {
type: 'bar',
background: 'transparent',
height: 350,
toolbar: {
  show: false,
},
},
colors: ['#2962ff', '#d50000', '#2e7d32', '#ff6d00', '#583cb3'],
plotOptions: {
bar: {
  distributed: true,
  borderRadius: 4,
  horizontal: false,
  columnWidth: '40%',
},
},
dataLabels: {
enabled: false,
},
fill: {
opacity: 1,
},
grid: {
borderColor: '#55596e',
yaxis: {
  lines: {
    show: true,
  },
},
xaxis: {
  lines: {
    show: true,
  },
},
},
legend: {
labels: {
  colors: 'black',
},
show: true,
position: 'top',
},
stroke: {
colors: ['transparent'],
show: true,
width: 2,
},
tooltip: {
shared: true,
intersect: false,
theme: 'dark',
},
xaxis: {
categories: ['post1', 'Post2', 'post3', 'post4', 'post5'],
title: {
  style: {
    color: '#f5f7ff',
  },
},
axisBorder: {
  show: true,
  color: '#55596e',
},
axisTicks: {
  show: true,
  color: '#55596e',
},
labels: {
  style: {
    colors: '#f5f7ff',
  },
},
},
yaxis: {
title: {
  text: 'Like',
  style: {
    color: '#f5f7ff',
  },
},
axisBorder: {
  color: '#55596e',
  show: true,
},
axisTicks: {
  color: '#55596e',
  show: true,
},
labels: {
  style: {
    colors: '#f5f7ff',
  },
},
},
};

const barChart = new ApexCharts(
document.querySelector('#bar-chart'),
barChartOptions
);
barChart.render();

// AREA CHART
const areaChartOptions = {
series: [
{
  name: 'like',
  data: [31, 40, 28, 51, 42, 109, 100],
},
{
  name: 'comment',
  data: [11, 32, 45, 32, 34, 52, 41],
},
],
chart: {
type: 'area',
background: 'transparent',
height: 350,
stacked: false,
toolbar: {
  show: false,
},
},
colors: ['#00ab57', '#d50000'],
labels: ['Post 1', 'Post 2', 'Post 3', 'Post 4', 'Post 5', 'Post 6', 'Post 7'],
dataLabels: {
enabled: false,
},
fill: {
gradient: {
  opacityFrom: 0.4,
  opacityTo: 0.1,
  shadeIntensity: 1,
  stops: [0, 100],
  type: 'vertical',
},
type: 'gradient',
},
grid: {
borderColor: '#55596e',
yaxis: {
  lines: {
    show: true,
  },
},
xaxis: {
  lines: {
    show: true,
  },
},
},
legend: {
labels: {
  colors: 'Black',
},
show: true,
position: 'top',
},
markers: {
size: 6,
strokeColors: '#1b2635',
strokeWidth: 3,
},
stroke: {
curve: 'smooth',
},
xaxis: {
axisBorder: {
  color: '#55596e',
  show: true,
},
axisTicks: {
  color: '#55596e',
  show: true,
},
labels: {
  offsetY: 5,
  style: {
    colors: 'black',
  },
},
},
yaxis: [
{
  title: {
    text: 'like',
    style: {
      color: '#f5f7ff',
    },
  },
  labels: {
    style: {
      colors: ['#f5f7ff'],
    },
  },
},
{
  opposite: true,
  title: {
    text: 'comment',
    style: {
      color: '#f5f7ff',
    },
  },
  labels: {
    style: {
      colors: ['#f5f7ff'],
    },
  },
},
],
tooltip: {
shared: true,
intersect: false,
theme: 'dark',
},
};

const areaChart = new ApexCharts(
document.querySelector('#area-chart'),
areaChartOptions
);
areaChart.render();


