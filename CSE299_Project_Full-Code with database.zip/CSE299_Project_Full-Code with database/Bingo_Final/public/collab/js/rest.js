function fetchProjects(searchQuery = "") {
  let url = "/data3";
  if (searchQuery) {
    url += `?search=${encodeURIComponent(searchQuery)}`;
  }

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      console.log("Received data:", data);
      displayProjects(data);
    })
    .catch((error) => console.error("Error fetching data:", error));
}

function displayProjects(data) {
  const projectsContainer = document.getElementById("collabContainer");
  projectsContainer.innerHTML = ""; // Clear previous results

  if (data.length === 0) {
    projectsContainer.innerHTML = "<p>No projects found.</p>";
    return;
  }

  data.forEach((project) => {
    const projectDiv = document.createElement("div");
    projectDiv.classList.add("main-body-individual-project-seperation-div");
    projectDiv.innerHTML = `
      <div class="main-body-text">
        <h1>${project.title}</h1>
        <div class="project1">
          <h2>Category: ${project.category}</h2>
          <h2>Skill Requirement:</h2>
          <div class="features">
            <div class="feature">Python</div>
            <div class="feature">Deep learning</div>
            <div class="feature">Data Analysis</div>
          </div>
          <div class="short-description">
            <p>
              <b>Collab project description</b> <br>
              ${project.short_description}
            </p>
          </div>
        </div>
        <button class="email-button" onclick="location.href='mailto:${project.email}'">
          <p><strong>Email: ${project.email}</strong></p>
        </button>
      </div>
    `;
    projectsContainer.appendChild(projectDiv);
  });
}

// Function to handle search input
function handleSearchInput() {
  const searchInput = document.getElementById("searchInput").value;
  console.log("Search input:", searchInput);
  fetchProjects(searchInput);
}

// Initialize fetchProjects with empty search query on page load
fetchProjects();
