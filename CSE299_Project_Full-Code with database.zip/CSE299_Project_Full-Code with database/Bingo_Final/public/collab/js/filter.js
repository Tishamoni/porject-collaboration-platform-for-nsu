//drop down for filtering
function toggleDropdown() {
    var dropdown = document.getElementById("filterOptions");
    if (dropdown.style.display === "block") {
      dropdown.style.display = "none";
    } else {
      dropdown.style.display = "block";
    }
  }