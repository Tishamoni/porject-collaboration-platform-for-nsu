document.getElementById("latestFilter").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent the default link behavior
  
    fetch("/latest-collab")
      .then(response => response.json())
      .then(data => {
        const projectsContainer = document.getElementById("collabContainer");
        projectsContainer.innerHTML = ""; // Clear existing projects
  
        data.forEach(project => {
          const projectDiv = document.createElement("div");
          projectDiv.classList.add("main-body-individual-project-seperation-div");
          projectDiv.innerHTML = `
            <div class="main-body-text">
              <h1>${project.title}</h1>
              <div class="project1">
                <h2>Category: ${project.category}</h2>
                <h2>Skill Requirment:</h2>
                <div class="features">
                  <div class="feature">Python</div>
                  <div class="feature">Deep learning</div>
                  <div class="feature">Data Analyse</div>
                </div>
                <div class="short-description">
                  <p>
                    <b>Collab project description</b> <br>
                    ${project.short_description}
                  </p>
                </div>
              </div>
              <button class="email-button" onclick="location.href='mailto:${project.email}'">
                <p><strong>Email: ${project.email}</strong></p>
              </button>
            </div>
          `;
          projectsContainer.appendChild(projectDiv);
        });
      })
      .catch(error => console.error("Error fetching data:", error));
  });
  