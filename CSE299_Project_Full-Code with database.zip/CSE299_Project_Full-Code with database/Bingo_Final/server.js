//importing necessary modules
import express from "express";
import mysql from "mysql";
import bodyParser from "body-parser";
import { dirname } from "path";
import path from "path";
import { fileURLToPath } from "url";
//week 5
import session from "express-session";
import moment from "moment";
// import { getRandomValues } from "crypto";

import multer from 'multer';

const __dirname = dirname(fileURLToPath(import.meta.url));

//boilerplate
const app = express();



// Multer configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
      cb(null, path.join(__dirname, 'public', 'showcase', 'images'));
  },
  filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({ storage });

//Port where the output is visible
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));

// Set the views directory
app.set("views", path.join(__dirname, "views"));

// Set EJS as the view engine
app.set("view engine", "ejs");

// Use session middleware
app.use(
  session({
    secret: "Hello from a superman",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Change to true if using HTTPS
      maxAge: 8600000000, // Session duration in milliseconds (e.g., 1 day)
    },
  })
);

// Middleware to check if user is logged in
function requireLogin(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.redirect("/homepage1-nonUser");
  }
}



//I have added this piece of code
//app.get('/', function (req, res, next) {
//  res.send("Hello world");
//});
//added code block ends here

//Connection with database
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  //I have changed the port to match my port
  port: "3306",
  //database name
  database: "bingo",
});

//Code that is printing if connected to the database or not
connection.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL: ", err);
    return;
  }
  console.log("Connected to MySQL database");
});



// Endpoint to retrieve data from MySQL database
app.get("/data1", (req, res) => {
  let sql = `SELECT project.*, GROUP_CONCAT(Keywords.keyword) AS features
              FROM project
              LEFT JOIN Keywords ON project.project_id = keywords.project_id`;

  // Check if search query parameter is provided
  if (req.query.search) {
    const searchQuery = req.query.search.toLowerCase();
    // Add search condition to SQL query
    sql += ` WHERE LOWER(project.title) LIKE '%${searchQuery}%' 
             OR LOWER(project.category) LIKE '%${searchQuery}%' 
             OR LOWER(Keywords.keyword) LIKE '%${searchQuery}%'`;
  }

  sql += ` GROUP BY project.project_id`;

  connection.query(sql, (error, results, fields) => {
    if (error) {
      console.error("Error retrieving data from MySQL:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      // Send the retrieved data as JSON response
      res.json(results);
    }
  });
});




app.get("/data3", (req, res) => {
  let sql = `SELECT * FROM collaboration`;
  let searchParams = [];

  // Check if search query parameter is provided
  if (req.query.search) {
    const searchQuery = `'%${req.query.search.toLowerCase()}%'`;
    sql += ` WHERE LOWER (collaboration.title) LIKE ${searchQuery} OR LOWER (collaboration.category) LIKE ${searchQuery}`;
    console.log(sql);
  }

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving data from MySQL:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      console.log(results);
      res.json(results);
    }
  });
});









//Routing function structure --> app.METHOD(PATH, HANDLER)
//whenever the /register url is accessed the register.html file is loaded

app.get("/register", (req, res) => {
  res.sendFile(__dirname + "/public/register/register.html");
});

app.get("/login", (req, res) => {
  res.sendFile(__dirname + "/public/login/login.html");
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/homepage1/homepage1.html");
});

app.get("/homepage1", requireLogin, (req, res) => {
  res.sendFile(__dirname + "/public/homepage1/homepage1.html");
});

app.get("/homepage1-nonUser", (req, res) => {
  res.render("homepage1-nonUser");
});

app.get("/showcase", requireLogin, (req, res) => {
  const userId = req.session.userId;

  let sql = `SELECT project.*, 
                  GROUP_CONCAT(Keywords.keyword) AS features, 
                  (SELECT COUNT(*) FROM \`like\` WHERE \`like\`.project_id = project.project_id) AS likeCount,
                  (SELECT COUNT(*) FROM comment WHERE comment.project_id = project.project_id) AS commentCount
            FROM project
            LEFT JOIN Keywords ON project.project_id = keywords.project_id`;

// Check if search query parameter is provided
if (req.query.search) {
  const searchQuery = req.query.search.toLowerCase();
  // Add search condition to SQL query
  sql += ` WHERE LOWER(project.title) LIKE '%${searchQuery}%' 
           OR LOWER(project.category) LIKE '%${searchQuery}%' 
           OR LOWER(Keywords.keyword) LIKE '%${searchQuery}%'`;
}


sql += ` GROUP BY project.project_id`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving user projects:", error);
      res.status(500).send("Internal server error");
    } else {
      console.log(results);
      // res.json(results);
      // Render the showcase.ejs file with the user projects data
      res.render("showcase", { projects: results });
    }
  });
});

// app.get("/upload", (req, res) => {
//   res.sendFile(__dirname + "/public/upload/upload.html");
// });

app.get("/collab", requireLogin, (req, res) => {
  res.sendFile(__dirname + "/public/collab/collab.html");
});



app.get("/dashboard-help", requireLogin, (req, res) => {
  res.render("dashboard-help");
});

app.get("/dashboard-notification", requireLogin, (req, res) => {
  res.render("dashboard-notification");
});


app.get("/dashboard-main", requireLogin, (req, res) => {
  const userId = req.session.userId;

  // Query to retrieve count of user projects, collab posts, likes, and comments
  const sql = `
  SELECT 
    (SELECT COUNT(*) FROM project WHERE NSU_ID = ${userId}) AS total_projects,
    (SELECT COUNT(*) FROM collaboration WHERE NSU_ID = ${userId}) AS total_collabs,
    (SELECT COUNT(*) FROM \`like\` WHERE project_id IN (SELECT project_id FROM project WHERE NSU_ID = ${userId})) AS total_likes,
    (SELECT COUNT(*) FROM comment WHERE project_id IN (SELECT project_id FROM project WHERE NSU_ID = ${userId})) AS total_comments
`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving infos:", error);
      res.status(500).send("Internal server error");
    } else {
      console.log(results);
      // Render the dashboard.ejs file with the user projects data
      res.render("dashboard-main", {
        total_projects: results[0].total_projects,
        total_collabs: results[0].total_collabs,
        total_likes: results[0].total_likes,
        total_comments: results[0].total_comments
      });
    }
  });
});



// GET dashboard project for active user
app.get("/dashboard-project", requireLogin, (req, res) => {
  const userId = req.session.userId;

  // Query to retrieve user projects and their keywords
  const sql = `SELECT project.*, GROUP_CONCAT(Keywords.keyword) AS keywords
               FROM project
               LEFT JOIN Keywords ON project.project_ID = keywords.project_ID
               WHERE project.NSU_ID = ${userId}
               GROUP BY project.project_ID`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving user projects:", error);
      res.status(500).send("Internal server error");
    } else {
      console.log(results);
      // Render the dashboard.ejs file with the user projects data
      res.render("dashboard-project", { projects: results });
    }
  });
});

// GET dashboard collaboration for active user
app.get("/dashboard-collab", requireLogin, (req, res) => {
  const userId = req.session.userId;

  // Query to retrieve data from the database
  const sql = `SELECT * from collaboration where nsu_id = ${userId}`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving user collaboration posts:", error);
      res.status(500).send("Internal server error");
    } else {
      console.log(results);
      // Render the dashboard.ejs file with the user projects data
      res.render("dashboard-collab", { posts: results });
    }
  });
});

// DASHBOARD route
app.get("/dashboard-profile", requireLogin, (req, res) => {
  // Retrieve user information based on the session
  const userId = req.session.userId;
  const sql = `SELECT * FROM user WHERE NSU_ID = ${userId}`;

  connection.query(sql, (err, result) => {
    if (err || result.length === 0) {
      console.error("Error fetching user data.");
      res.redirect("/login");
    } else {
      const user = result[0];

      const dob = new Date(user.date_of_birth);
      // Format the date of birth to display only the day, month, and year
      const formattedDOB = dob.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      });

      // Add the formatted date of birth back to the user object
      user.date_of_birth = formattedDOB;

      // Log user data to the console
      console.log("User Data:", user);
      res.render("dashboard-profile", { user }); // Pass user data to the template
    }
  });
});

//GET password route
app.get("/dashboard-pass", requireLogin, (req, res) => {
  res.render("dashboard-pass");
});

// change password
app.post("/dashboard-pass", requireLogin, (req, res) => {
  var oldPassword = req.body.oldPassword;
  var newPassword = req.body.newPassword;
  var confirmPassword = req.body.confirmPassword;

  if (newPassword != confirmPassword) res.render("dashboard-pass");

  // Retrieve user information based on the session
  const userId = req.session.userId;
  const sql = `SELECT * FROM user WHERE NSU_ID = ${userId}`;

  connection.query(sql, (err, result) => {
    if (err || result.length === 0) {
      console.error("Error fetching user data.");
      res.redirect("/login");
    } else {
      const user = result[0];
      var decodedPassword = atob(user.password);
      console.log(decodedPassword);

      if (decodedPassword == oldPassword) {
        var encodedPassword = btoa(newPassword);
        console.log(encodedPassword);
        var sql = `UPDATE user SET password = '${encodedPassword}' WHERE NSU_ID = ${userId}`;
        connection.query(sql, (err, result) => {
          if (err) {
            console.log("Error Dectected.");
            // res.send("Access Denied. ;)");
            // res.sendFile(__dirname + "/login.html");
            res.redirect("/login");
          } else {
            res.redirect("/dashboard-profile");
          }
        });
      }

      // Log user data to the console
      // console.log("User Data:", user);
      // res.render("dashboard-profile", { user }); // Pass user data to the template
    }
  });
});

//The same /login path has a get and a post request handling part?!
//gem method commented out
//The post request cannot be accessed when calling /login
//LOGIN

app.post("/login", (req, res) => {
  const id = req.body.id;
  const password = req.body.password;

  const sql = `SELECT password FROM user WHERE NSU_ID = ?`;

  connection.query(sql, [id], (err, result) => {
    if (err) {
      console.log("Error detected.");
      res.redirect("/login?error=Internal server error");
    } else {
      if (result.length === 0) {
        console.log("ID doesn't exist");
        res.redirect("/login?error=ID doesn't exist");
      } else {
        const decodedString = Buffer.from(result[0].password, 'base64').toString('utf8');

        if (decodedString === password) {
          console.log("Successfully matched");
          req.session.userId = id;
          res.redirect("/dashboard-profile");
        } else {
          console.log("Failed to match.");
          res.redirect("/login?error=Incorrect password");
        }
      }
    }
  });
});

// LOGOUT route
app.get("/logout", (req, res) => {
  // Destroy the session to log out the user
  req.session.destroy((err) => {
    if (err) {
      console.error("Error logging out:", err);
    }
    res.redirect("/login");
  });
});

//REGISTER
app.post("/register", (req, res) => {
  // console.log(req.body.firstname);
  // console.log(req.body.student_id);

  //The post request is returning a body and accessing the student_id and firstname part for it
  var fname = req.body.fname;
  var lname = req.body.lname;
  var mail = req.body.mail;
  var password = req.body.pass;
  var date = req.body.date;
  var id = req.body.id;
  var dept = req.body.dept;
  var gender = req.body.gender;

  //Hash block starts
  var inputString = password;

  //Encoding the input String using base64 hash and storing in the variable
  var encodedString = btoa(inputString);

  //infos is a database table with name and sid(Pkey)
  var sql = `Insert into user (NSU_ID, first_name ,last_name , password, email, gender, date_of_birth, department) Values(${id}, '${fname}', '${lname}', '${encodedString}' , '${mail}', '${gender}', '${date}', '${dept}')`;

  //Query implementation
  connection.query(sql, (err) => {
    if (err) {
      console.log("Error Detected. Database error or Duplicate sid");
      // res.send("Registration Failed!");
      res.redirect("/register?error=Registration failed due to duplicate ID or database error. Please try again.");
    } else {
      console.log("Successfully inserted 1 record");
      showTable();
      res.redirect("/login");
    }
  });

});

//Shows the entire database table
function showTable() {
  connection.query("select * from user", (err, result) => {
    if (err) throw err;
    

    console.log(result);
  });
}

app.post("/upload", upload.single('imageFile'), (req, res) => {
  // console.log(req.body.firstname);
  // console.log(req.body.student_id);

  // Get current upload time and date
  const uploadTime = new Date().toLocaleTimeString();
  const uploadDate = moment().format('YYYY-MM-DD');
  
  //The post request is returning a body and accessing the student_id and firstname part for it
  // var title = req.body.projectName;
  // var category = req.body.category;
  // var keywords = req.body.keyWord;
  // var description = req.body.Description;
  // const userId = req.session.userId;
  // var nsu_id = userId;
  
  // const image = req.file.filename;

  // var formattedDate = date.substring(0, 4) + "-" + date.substring(5, 7) +


  const { projectName, category, keyWord, Description } = req.body;
  const userId = req.session.userId; // Assuming userId is stored in session
  const projectImage = req.file.filename;
  const image = "images/" + projectImage;
 
  const features = req.body.keyWord;
  const featuresArray=features.split(',');
  const trimmedFeaturesArray=featuresArray.map(feature=> feature.trim());
  const keywords=trimmedFeaturesArray;





  var sql = `Insert into project (title, category, short_description, NSU_ID, upload_time, upload_date,  thumbnail) VALUES (?, ?, ?, ?, ?, ?, ?)`;


  //Query implementation
  connection.query(sql, [projectName, category, Description, userId, uploadTime, uploadDate, image], (err) => {
    if (err) {
        console.log(err);
        res.status(500).send('Failed to insert record');
    } else {
        console.log('Successfully inserted 1 record');
        res.redirect('/showcase');
    }
  });






  sql = `select MAX(project_ID) as id from project`;



  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving user projects:", error);
      res.status(500).send("Internal server error");
    } else {
      console.log(results);
      sql = `Insert into keywords (project_ID, keyword) VALUES (?, ?)`;
      const project_ID = results[0].id;
      keywords.forEach(keyword => {
      connection.query(sql, [project_ID, keyword], (err) => {
        if (err) {
            console.log(err);
            res.status(500).send('Failed to insert record');
        } else {
            console.log('Successfully inserted 1 record in keywords table');
    
        }
      });
    })
    }
  });

  
  

  





});


app.post("/collab-upload", (req, res) => {
  // console.log(req.body.firstname);
  // console.log(req.body.student_id);

  // Get current upload time and date
  const uploadTime = new Date().toLocaleTimeString();
  const uploadDate = moment().format('YYYY-MM-DD');

  //The post request is returning a body and accessing the student_id and firstname part for it
  var title = req.body.projectName;
  var category = req.body.category;
  var keywords = req.body.keyWord;
  var description = req.body.Description;
  var email = req.body.email;

  const userId = req.session.userId;
  var nsu_id = userId;

  console.log(req.body);

  // var formattedDate = date.substring(0, 4) + "-" + date.substring(5, 7) +

  console.log(title);
  console.log(category);
  console.log(keywords);
  console.log(description);
  console.log(nsu_id);
  console.log(uploadTime);
  console.log(uploadDate);

  var sql = `Insert into collaboration (title, category, short_description, email, NSU_ID, upload_time, upload_date) Values('${title}', '${category}', '${description}', '${email}', ${nsu_id}, '${uploadTime}', '${uploadDate}')`;

  //Query implementation
  connection.query(sql, (err) => {
    if (err) {
      console.log(err);
      res.send(" Failed!");
    } else {
      console.log("Successfully inserted 1 record");
      // res.send("Successfully inserted 1 record");
      res.redirect("/collab");
    }
  });
});


// filter



// latest collab
app.get("/latest-collab", (req, res) => {
  const sql = `SELECT * from collaboration
               ORDER BY collaboration.upload_date DESC, collaboration.upload_time DESC`;

  connection.query(sql, (error, results, fields) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.json(results);
    }
  });
});


// oldest collab
app.get("/oldest-collab", (req, res) => {
  const sql = `SELECT * from collaboration
               ORDER BY collaboration.upload_date asc, collaboration.upload_time asc`;

  connection.query(sql, (error, results, fields) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.json(results);
    }
  });
});


// Endpoint to retrieve latest projects
app.get("/popular-projects", (req, res) => {

  const sql = `SELECT project.*, 
  GROUP_CONCAT(Keywords.keyword) AS features, 
  (SELECT COUNT(*) FROM \`like\` WHERE \`like\`.project_id = project.project_id) AS likeCount
  FROM project
  LEFT JOIN Keywords ON project.project_id = keywords.project_id
  GROUP BY project.project_id
  ORDER BY likeCount DESC`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      // res.json(results);
      res.render("showcase", { projects: results });
    }
  });
});

// Endpoint to retrieve latest projects
app.get("/latest-projects", (req, res) => {
  const sql = `SELECT project.*, GROUP_CONCAT(Keywords.keyword) AS features
               FROM project
               LEFT JOIN Keywords ON project.project_id = keywords.project_id
               GROUP BY project.project_id
               ORDER BY project.upload_date DESC, project.upload_time DESC`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.render("showcase", { projects: results });
    }
  });
});


// Endpoint to retrieve latest projects
app.get("/top-projects", (req, res) => {

  const userId = req.session.userId;

  const sql = `SELECT likeCount
  FROM (
      SELECT COUNT(*) AS likeCount
      FROM \`like\`
      WHERE project_id IN (
          SELECT project_id
          FROM project
          WHERE NSU_ID = ${userId}
      )
      GROUP BY project_id
      ORDER BY likeCount DESC
      LIMIT 5
  ) AS mostLikedProjects`;

  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.json(results);
      // res.render("showcase", { projects: results });
    }
  });
});





// Handle Like Retrieval
app.get("/like", (req, res) => {
  const projectId = req.params.projectId;
  // Query database to fetch the current like count for the specified project ID
  // Replace the placeholder logic with actual database query
  const sql = `select count(*), project_ID from \`like\` group BY project_ID`;
  connection.query(sql, (error, results) => {
    if (error) {
      console.error("Error retrieving latest projects:", error);
      console.log(results);
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.json(results);
    }
  });
  
});

// Handle Like Addition
app.post("/like/add", (req, res) => {
  const projectId = req.body.projectId;
  const userId = req.body.userId; // Assuming you have user authentication
  // Insert a new row in the likes table for the specified project and user
  // Replace the placeholder logic with actual database insert
  db.query("INSERT INTO like (NSU_ID, project_id) VALUES (?, ?)", [userId, projectId]);
  res.sendStatus(200);
});

// Handle Like Removal
app.post("/like/remove", (req, res) => {
  const projectId = req.body.projectId;
  const userId = req.body.userId; // Assuming you have user authentication
  // Delete the row from the likes table for the specified project and user
  // Replace the placeholder logic with actual database delete
  db.query("DELETE FROM like WHERE NSU_ID = ? AND project_id = ?", [userId, projectId]);
  res.sendStatus(200);
});













// Endpoint to retrieve comments for a specific project
app.get("/comments/:projectId", (req, res) => {
  const projectId = req.params.projectId;
  console.log(projectId);
  const sql = `SELECT * FROM comment WHERE project_id = ?`;
  connection.query(sql, [projectId], (error, results) => {
      if (error) {
          console.error("Error retrieving comments:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          res.json(results);
      }
  });
});

// Endpoint to add a new comment
app.post("/comments/add", (req, res) => {
  const { projectId, commentText } = req.body;
  const sql = `INSERT INTO comment (project_id, comment_text) VALUES (?, ?)`;
  connection.query(sql, [projectId, commentText], (error, results) => {
      if (error) {
          console.error("Error adding comment:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          res.status(200).json({ message: "Comment added successfully" });
      }
  });
});




//Displays which port the server is running on
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
